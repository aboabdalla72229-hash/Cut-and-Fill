إصلاح خطأ ./gradlew: No such file or directory

هذه النسخة تحتوي على gradlew launcher مناسب لـ AIDE.

مهم:
1) احذف/أغلق المشروع القديم في AIDE.
2) فك ضغط هذه النسخة في مجلد جديد.
3) افتح المجلد الجديد من AIDE كـ Existing Project.
4) Build/Run.
5) إذا ظهر خطأ جديد، صوّر الشاشة وأرسلها.

إذا ظهر:
Gradle executable was not found
افتح Terminal داخل AIDE ونفّذ:
gradle -v
وأرسل النتيجة.

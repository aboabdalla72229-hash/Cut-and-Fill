SurveyQuant 2.0 - AIDE Edition

هذه نسخة موسعة للعمل من الهاتف بدون AndroidX.
الموجود:
- CSV/TXT: Point, Easting, Northing, Elevation, Code
- تحميل سطحين
- TIN بواسطة Delaunay/Bowyer-Watson
- Contours من مثلثات TIN
- مقارنة سطح 1 مع سطح 2: متوسط وأقل وأكبر فرق منسوب عند نقاط السطح الأول الواقعة داخل TIN السطح الثاني
- تصدير DXF يحتوي نقاط ومناسيب و3DFACE للـTIN وخطوط الكنتور

طريقة AIDE:
1. فك الضغط.
2. افتح المجلد في AIDE كـ Existing Project.
3. Build/Run.
4. لو AIDE طلب Gradle/SDK، اختر النسخة المثبتة عندك.
5. بعد نجاح البناء ثبّت APK.

ملاحظة SDR:
ملفات SDR ليست كلها بنفس البنية، لذلك لن أضع parser عشوائيًا يفسد الإحداثيات. المرحلة التالية بعد اختبار CSV/TXT على هاتفك هي إضافة قوالب SDR الشائعة أو استيراد SDR بعد معرفة صيغة الملف عندك.


package com.surveyquant.app;

import java.util.*;
import java.io.*;

public class SurveyEngine {
    public static class Point {
        public String id, code;
        public double x,y,z;
        public Point(String id,double x,double y,double z,String code){
            this.id=id;this.x=x;this.y=y;this.z=z;this.code=code==null?"":code;
        }
    }
    public static class Triangle {
        public Point a,b,c;
        public Triangle(Point a,Point b,Point c){this.a=a;this.b=b;this.c=c;}
    }
    public static class Segment {
        public double x1,y1,x2,y2,z;
        public Segment(double x1,double y1,double x2,double y2,double z){
            this.x1=x1;this.y1=y1;this.x2=x2;this.y2=y2;this.z=z;
        }
    }

    public ArrayList<Point> points=new ArrayList<Point>();
    public ArrayList<Triangle> triangles=new ArrayList<Triangle>();

    static class C { double x,y; C(double x,double y){this.x=x;this.y=y;} }
    static class WorkTri {
        Point a,b,c;
        WorkTri(Point a,Point b,Point c){this.a=a;this.b=b;this.c=c;}
        boolean has(Point p){return a==p||b==p||c==p;}
        boolean contains(double x,double y){
            double d=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);
            if(Math.abs(d)<1e-12)return false;
            double u=((b.y-c.y)*(x-c.x)+(c.x-b.x)*(y-c.y))/d;
            double v=((c.y-a.y)*(x-c.x)+(a.x-c.x)*(y-c.y))/d;
            double w=1-u-v;
            return u>=0&&v>=0&&w>=0;
        }
    }

    public void buildTIN(){
        triangles.clear();
        if(points.size()<3)return;
        double minx=points.get(0).x,maxx=minx,miny=points.get(0).y,maxy=miny;
        for(Point p:points){minx=Math.min(minx,p.x);maxx=Math.max(maxx,p.x);miny=Math.min(miny,p.y);maxy=Math.max(maxy,p.y);}
        double dx=maxx-minx,dy=maxy-miny,d=Math.max(dx,dy);
        if(d==0)return;
        Point s1=new Point("__S1",minx-20*d,miny-20*d,0,"");
        Point s2=new Point("__S2",minx+40*d,miny-20*d,0,"");
        Point s3=new Point("__S3",minx-20*d,miny+40*d,0,"");
        ArrayList<WorkTri> work=new ArrayList<WorkTri>();
        work.add(new WorkTri(s1,s2,s3));

        for(Point p:points){
            ArrayList<WorkTri> bad=new ArrayList<WorkTri>();
            for(WorkTri t:work) if(inCircumcircle(p,t)) bad.add(t);
            HashMap<String,int[]> edgeCount=new HashMap<String,int[]>();
            ArrayList<Point[]> edges=new ArrayList<Point[]>();
            for(WorkTri t:bad){
                Point[][] es={{t.a,t.b},{t.b,t.c},{t.c,t.a}};
                for(Point[] e:es){
                    String k=edgeKey(e[0],e[1]);
                    int[] cnt=edgeCount.get(k);
                    if(cnt==null){edgeCount.put(k,new int[]{1});edges.add(e);}
                    else cnt[0]++;
                }
            }
            work.removeAll(bad);
            for(Point[] e:edges){
                if(edgeCount.get(edgeKey(e[0],e[1]))[0]==1) work.add(new WorkTri(e[0],e[1],p));
            }
        }
        for(WorkTri t:work){
            if(t.has(s1)||t.has(s2)||t.has(s3))continue;
            if(Math.abs(area2(t.a,t.b,t.c))>1e-10) triangles.add(new Triangle(t.a,t.b,t.c));
        }
    }

    private String edgeKey(Point a,Point b){
        int ia=System.identityHashCode(a),ib=System.identityHashCode(b);
        return ia<ib?ia+"_"+ib:ib+"_"+ia;
    }
    private double area2(Point a,Point b,Point c){return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);}
    private boolean inCircumcircle(Point p,WorkTri t){
        double ax=t.a.x-p.x, ay=t.a.y-p.y;
        double bx=t.b.x-p.x, by=t.b.y-p.y;
        double cx=t.c.x-p.x, cy=t.c.y-p.y;
        double det=(ax*ax+ay*ay)*(bx*cy-by*cx)
                 -(bx*bx+by*by)*(ax*cy-ay*cx)
                 +(cx*cx+cy*cy)*(ax*by-ay*bx);
        double orient=area2(t.a,t.b,t.c);
        return orient>0?det>1e-9:det<-1e-9;
    }

    public Double interpolate(double x,double y){
        for(Triangle t:triangles){
            double d=area2(t.a,t.b,t.c);
            if(Math.abs(d)<1e-12)continue;
            double u=area2(new Point("",x,y,0,""),t.b,t.c)/d;
            double v=area2(t.a,new Point("",x,y,0,""),t.c)/d;
            double w=1-u-v;
            if(u>=-1e-9&&v>=-1e-9&&w>=-1e-9)return u*t.a.z+v*t.b.z+w*t.c.z;
        }
        return null;
    }

    public ArrayList<Segment> contours(double interval){
        ArrayList<Segment> out=new ArrayList<Segment>();
        if(interval<=0||triangles.size()==0)return out;
        double min=Double.MAX_VALUE,max=-Double.MAX_VALUE;
        for(Point p:points){min=Math.min(min,p.z);max=Math.max(max,p.z);}
        double first=Math.ceil(min/interval)*interval;
        for(double level=first;level<=max+1e-9;level+=interval){
            for(Triangle t:triangles){
                ArrayList<double[]> q=new ArrayList<double[]>();
                addCross(q,t.a,t.b,level);
                addCross(q,t.b,t.c,level);
                addCross(q,t.c,t.a,level);
                if(q.size()==2)out.add(new Segment(q.get(0)[0],q.get(0)[1],q.get(1)[0],q.get(1)[1],level));
            }
        }
        return out;
    }

    private void addCross(ArrayList<double[]> q,Point a,Point b,double z){
        if((z>=Math.min(a.z,b.z)-1e-10)&&(z<=Math.max(a.z,b.z)+1e-10)&&Math.abs(a.z-b.z)>1e-12){
            double t=(z-a.z)/(b.z-a.z);
            if(t>=-1e-9&&t<=1+1e-9)q.add(new double[]{a.x+t*(b.x-a.x),a.y+t*(b.y-a.y)});
        }
    }

    public double[] stats(){
        if(points.size()==0)return new double[]{0,0,0};
        double min=Double.MAX_VALUE,max=-Double.MAX_VALUE,sum=0;
        for(Point p:points){min=Math.min(min,p.z);max=Math.max(max,p.z);sum+=p.z;}
        return new double[]{min,max,sum/points.size()};
    }

    public double[] bounds(){
        if(points.size()==0)return new double[]{0,0,0,0};
        double minx=Double.MAX_VALUE,maxx=-Double.MAX_VALUE,miny=Double.MAX_VALUE,maxy=-Double.MAX_VALUE;
        for(Point p:points){minx=Math.min(minx,p.x);maxx=Math.max(maxx,p.x);miny=Math.min(miny,p.y);maxy=Math.max(maxy,p.y);}
        return new double[]{minx,maxx,miny,maxy};
    }

    public static String dxf(ArrayList<Point> pts,ArrayList<Triangle> tris,ArrayList<Segment> segs){
        StringBuilder s=new StringBuilder();
        s.append("0\nSECTION\n2\nENTITIES\n");
        for(Point p:pts){
            s.append("0\nPOINT\n8\nSURVEY_POINTS\n10\n").append(p.x).append("\n20\n").append(p.y).append("\n30\n").append(p.z).append("\n");
            s.append("0\nTEXT\n8\nELEVATION\n10\n").append(p.x).append("\n20\n").append(p.y).append("\n40\n1.5\n1\n").append(p.z).append("\n");
        }
        for(Triangle t:tris){
            s.append("0\n3DFACE\n8\nTIN\n10\n").append(t.a.x).append("\n20\n").append(t.a.y).append("\n30\n").append(t.a.z)
             .append("\n11\n").append(t.b.x).append("\n21\n").append(t.b.y).append("\n31\n").append(t.b.z)
             .append("\n12\n").append(t.c.x).append("\n22\n").append(t.c.y).append("\n32\n").append(t.c.z)
             .append("\n13\n").append(t.c.x).append("\n23\n").append(t.c.y).append("\n33\n").append(t.c.z).append("\n");
        }
        for(Segment g:segs){
            s.append("0\nLINE\n8\nCONTOUR_").append(String.format(Locale.US,"%.3f",g.z))
             .append("\n10\n").append(g.x1).append("\n20\n").append(g.y1).append("\n30\n").append(g.z)
             .append("\n11\n").append(g.x2).append("\n21\n").append(g.y2).append("\n31\n").append(g.z).append("\n");
        }
        s.append("0\nENDSEC\n0\nEOF\n");
        return s.toString();
    }
}

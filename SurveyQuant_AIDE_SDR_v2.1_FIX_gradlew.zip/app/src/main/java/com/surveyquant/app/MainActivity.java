
package com.surveyquant.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    SurveyEngine a=new SurveyEngine(), b=new SurveyEngine();
    LinearLayout root,log;
    TextView status;
    int mode=0; // 0=A, 1=B
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setPadding(dp(8),dp(6),dp(8),dp(6));return v;}

    public void onCreate(Bundle x){super.onCreate(x);ui();}

    void ui(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(10),dp(10),dp(10),dp(10));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView title=t("SurveyQuant 2.0",26);title.setGravity(Gravity.CENTER);root.addView(title);
        status=t("جاهز. اختر ملف الرفع المساحي.",15);root.addView(status);
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.VERTICAL);
        Button impA=btn("📂 تحميل سطح 1");impA.setOnClickListener(v->{mode=0;pick();});
        Button impB=btn("📂 تحميل سطح 2 للمقارنة");impB.setOnClickListener(v->{mode=1;pick();});
        Button tin=btn("🔺 إنشاء TIN + كنتور");
        tin.setOnClickListener(v->{a.buildTIN(); showContours();});
        Button compare=btn("📐 مقارنة السطحين وحساب الفروق");
        compare.setOnClickListener(v->compare());
        Button dxf=btn("💾 تصدير DXF");
        dxf.setOnClickListener(v->exportDXF());
        bar.addView(impA);bar.addView(impB);bar.addView(tin);bar.addView(compare);bar.addView(dxf);
        root.addView(bar);
        ScrollView sv=new ScrollView(this);log=new LinearLayout(this);log.setOrientation(LinearLayout.VERTICAL);sv.addView(log);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    Button btn(String s){Button b=new Button(this);b.setText(s);return b;}

    void pick(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i,mode==0?100:101);
    }
    protected void onActivityResult(int r,int c,Intent d){
        super.onActivityResult(r,c,d);if(c!=RESULT_OK||d==null)return;
        if(r==200){try{save(d.getData());toast("تم حفظ DXF");}catch(Exception ex){toast("فشل حفظ DXF: "+ex.getMessage());}return;}
        try{
            SurveyEngine e=(r==100?a:b);readFile(d.getData(),e);
            status.setText((r==100?"سطح 1":"سطح 2")+" : "+e.points.size()+" نقطة");
            showStats(e);
        }catch(Exception ex){status.setText("خطأ: "+ex.getMessage());}
    }

    String sep(String s){
        String[] q={",",";","\\t","|"};String best=",";int m=0;
        for(String z:q){int n=s.split(z,-1).length;if(n>m){m=n;best=z;}}return best;
    }
    String norm(String s){return s.trim().toLowerCase(Locale.US).replace(" ","").replace("_","");}
    int find(String[] h,String... names){
        for(int i=0;i<h.length;i++)for(String n:names)if(norm(h[i]).equals(norm(n)))return i;return -1;
    }

    void readFile(Uri u,SurveyEngine e)throws Exception{
        e.points.clear();
        BufferedReader br=new BufferedReader(
            new InputStreamReader(getContentResolver().openInputStream(u),"UTF-8"));
        ArrayList<String> ls=new ArrayList<String>();
        String q;
        while((q=br.readLine())!=null) if(!q.trim().isEmpty()) ls.add(q);
        br.close();
        if(ls.size()==0)return;

        // Sokkia/SDR33 fixed-width point records:
        // 08TP + point number + Easting(10 chars) + Northing(10 chars) + Elevation(6 chars)
        boolean sdr=false;
        for(String line:ls) if(line.startsWith("08TP")) { sdr=true; break; }

        if(sdr){
            int count=0;
            for(String line:ls){
                if(!line.startsWith("08TP") || line.length()<58) continue;
                try{
                    String id=line.substring(18,20).trim();
                    // Some SDR exports may use a wider point-number field.
                    if(id.length()==0) id=line.substring(18,26).trim();
                    double east=Double.parseDouble(line.substring(20,30).trim());
                    double north=Double.parseDouble(line.substring(36,46).trim());
                    double elev=Double.parseDouble(line.substring(52,58).trim());
                    e.points.add(new SurveyEngine.Point(id,east,north,elev,""));
                    count++;
                }catch(Exception ex){
                    // fallback for a few SDR variants using whitespace fields
                    try{
                        String z=line.substring(4).trim();
                        String[] v=z.split("\\s+");
                        if(v.length>=4){
                            String id=v[0];
                            double east=Double.parseDouble(v[1]);
                            double north=Double.parseDouble(v[2]);
                            double elev=Double.parseDouble(v[3]);
                            e.points.add(new SurveyEngine.Point(id,east,north,elev,""));
                            count++;
                        }
                    }catch(Exception ignored){}
                }
            }
            if(count>0){
                status.setText("SDR33: "+count+" نقطة");
                return;
            }
        }

        // CSV/TXT fallback
        String sp=sep(ls.get(0));
        String[] h=ls.get(0).split(sp,-1);
        boolean header=false;
        for(String x:h){
            String n=norm(x);
            if(n.equals("easting")||n.equals("northing")||n.equals("elevation")||
               n.equals("point")||n.equals("code")||n.equals("x")||n.equals("y")||n.equals("z")) header=true;
        }
        int ei=find(h,"easting","east","x"),ni=find(h,"northing","north","y"),
            zi=find(h,"elevation","elev","z","rl","level"),
            ii=find(h,"point","pt","id","number","no"),ci=find(h,"code","description","desc");

        for(int r=header?1:0;r<ls.size();r++){
            String[] v=ls.get(r).split(sp,-1);
            try{
                if(header&&ei>=0&&ni>=0&&zi>=0){
                    e.points.add(new SurveyEngine.Point(
                        ii>=0?v[ii]:(""+(r+1)),
                        Double.parseDouble(v[ei].trim()),
                        Double.parseDouble(v[ni].trim()),
                        Double.parseDouble(v[zi].trim()),
                        ci>=0?v[ci].trim():""));
                } else {
                    ArrayList<Double> nums=new ArrayList<Double>();
                    for(String z:v) try{nums.add(Double.parseDouble(z.trim()));}catch(Exception ex){}
                    if(nums.size()>=3){
                        int k=nums.size();
                        e.points.add(new SurveyEngine.Point(""+(r+1),nums.get(k-3),nums.get(k-2),nums.get(k-1),""));
                    }
                }
            }catch(Exception ex){}
        }
    }

    void showStats(SurveyEngine e){
        double[] s=e.stats();double[] q=e.bounds();
        log.addView(t("النقاط: "+e.points.size()+" | Zmin: "+fmt(s[0])+" | Zmax: "+fmt(s[1])+" | Zavg: "+fmt(s[2]),14));
        log.addView(t("حدود الرسم X: "+fmt(q[0])+" إلى "+fmt(q[1])+" | Y: "+fmt(q[2])+" إلى "+fmt(q[3]),13));
    }
    void showContours(){
        if(a.points.size()<3){toast("حمّل سطح 1 أولاً");return;}
        a.buildTIN();double[] s=a.stats();double range=s[1]-s[0];double interval=range>50?5:range>20?2:1;
        ArrayList<SurveyEngine.Segment> c=a.contours(interval);
        log.addView(t("TIN: "+a.triangles.size()+" مثلث | كنتور: "+c.size()+" مقطع | الفاصل: "+fmt(interval),15));
        toast("تم إنشاء TIN والكنتور");
    }

    void compare(){
        if(a.points.size()<3||b.points.size()<3){toast("لازم تحمل سطحين أولاً");return;}
        a.buildTIN();b.buildTIN();
        double sum=0,min=Double.MAX_VALUE,max=-Double.MAX_VALUE;int n=0;
        for(SurveyEngine.Point p:a.points){
            Double z=b.interpolate(p.x,p.y);
            if(z!=null){double d=p.z-z;sum+=d;min=Math.min(min,d);max=Math.max(max,d);n++;}
        }
        if(n==0){toast("لا يوجد تداخل مكاني بين السطحين");return;}
        log.addView(t("مقارنة السطحين:",18));
        log.addView(t("عدد نقاط المقارنة: "+n+"\nمتوسط فرق المنسوب: "+fmt(sum/n)+"\nأقل فرق: "+fmt(min)+"\nأكبر فرق: "+fmt(max),16));
        toast("تم حساب فروق المناسيب");
    }

    void exportDXF(){
        if(a.points.size()<3){toast("حمّل سطح 1 وأنشئ TIN أولاً");return;}
        a.buildTIN();double[] s=a.stats();double range=s[1]-s[0];double interval=range>50?5:range>20?2:1;
        String data=SurveyEngine.dxf(a.points,a.triangles,a.contours(interval));
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/dxf");i.putExtra(Intent.EXTRA_TITLE,"SurveyQuant_Surface.dxf");
        pendingDXF=data;startActivityForResult(i,200);
    }
    String pendingDXF="";
    void save(Uri u)throws Exception{OutputStream o=getContentResolver().openOutputStream(u);o.write(pendingDXF.getBytes("UTF-8"));o.close();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    String fmt(double x){return String.format(Locale.US,"%.3f",x);}
}
